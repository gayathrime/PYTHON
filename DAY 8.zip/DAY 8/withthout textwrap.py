def wrap(string, max_width):
    result = ""

    for i in range(0, len(string), max_width):
        print("i =", i)
        print("slice =", string[i:i+max_width])

        result += string[i:i+max_width] + "\n"

        print("result =", repr(result))
        print()

    return result.rstrip()

print(wrap("ABCDEFGHIJKL", 4))